#include "global.h"
#include "dfuncs.h"
#include <inttypes.h>
#include <err.h>

lispval
callg(lispval (*fn)(void), intptr_t args[]) {
	err(1, "Implement callg!");
}
