void emul(long p, long q, long r, long long *s)
{
    *s = (long long)p * q +r;
}
